package com.example.aemaulana.footballmatchschedule

import com.example.aemaulana.footballmatchschedule.Model.Team

data class TeamResponse(val teams : List<Team>)