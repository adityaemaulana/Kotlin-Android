package com.example.aemaulana.footballmatchschedule

data class MatchResponse(val events : List<Match>)