package com.example.aemaulana.footballmatchschedule

import com.example.aemaulana.footballmatchschedule.Model.Match

data class MatchResponse(val events: List<Match>)